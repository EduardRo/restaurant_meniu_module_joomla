<div>
    <blockquote>
        <h3>Pentru a vedea programele de pregatire pentru Bac trebuie sa va logati</h3>
        <h4>Pentru a achizitiona un Program de pregatire trebuie sa aveti numarul necesar de credite in cont!
    </blockquote>
</div>